﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using requestorJobDetailsAPI.Models;
using System.Data;

namespace requestorJobDetailsAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class requestorDetailsController : ControllerBase
    {

        private readonly JobContext _context;

        public requestorDetailsController(JobContext context)
        {
            _context = context;
        }

        [HttpGet("GetRequestorDetails")]
        public async Task<IActionResult> GetPrGetRequestorDetailsoducts()
        {
            try
            {
                var requestorDetails = await _context.RequestorDetails.ToListAsync();
                return Ok(requestorDetails);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Failed to fetch details.", error = ex.Message });
            }
        }
        [HttpPost("InsertRequestorDetails")]
        public async Task<IActionResult> InsertRequestorDetails([FromForm] insertReqDetails requestorDetail, IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest(new { message = "No file uploaded or file is empty." });
                }

                if (file.ContentType.ToLower() != "application/pdf")
                {
                    return BadRequest(new { message = "Only PDF files are accepted." });
                }

                using (var memoryStream = new MemoryStream())
                {
                    await file.CopyToAsync(memoryStream);
                    requestorDetail.FileData = memoryStream.ToArray();
                    requestorDetail.FileMimeType = file.ContentType;
                }

                var req_name = new SqlParameter("@requestor_Name", requestorDetail.RequestorName);
                var req_Email = new SqlParameter("@requestor_Email", requestorDetail.RequestorEmail);
                var req_Desc = new SqlParameter("@requestor_Desc", requestorDetail.RequestorDesc);
                var state = new SqlParameter("@state", requestorDetail.State);
                var city = new SqlParameter("@city", requestorDetail.City);
                var pincode = new SqlParameter("@pincode", requestorDetail.Pincode);

                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC insert_RequesterDetails @requestor_Name, @requestor_Email, @requestor_Desc, @state, @city, @pincode",
                    req_name, req_Email, req_Desc, state, city, pincode);

                var updatedRequestors = await _context.RequestorDetails.ToListAsync();
                return Ok(updatedRequestors);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Failed to add employee details.", error = ex.Message });
            }
        }
    }
}
