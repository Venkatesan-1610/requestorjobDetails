﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace requestorJobDetailsAPI.Models;

public partial class JobContext : DbContext
{
    public JobContext()
    {
    }

    public JobContext(DbContextOptions<JobContext> options)
        : base(options)
    {
    }

    public virtual DbSet<RequestorDetail> RequestorDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=job;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<RequestorDetail>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("Id");

            entity.ToTable("requestor_Details");

            entity.Property(e => e.City)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("city");
            entity.Property(e => e.Pincode).HasColumnName("pincode");
            entity.Property(e => e.RequestorDesc)
                .IsUnicode(false)
                .HasColumnName("requestor_desc");
            entity.Property(e => e.RequestorEmail)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("requestor_Email");
            entity.Property(e => e.RequestorName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("requestor_Name");
            entity.Property(e => e.State)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("state");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
