﻿using System;
using System.Collections.Generic;

namespace requestorJobDetailsAPI.Models;

public partial class RequestorDetail
{
    public string RequestorName { get; set; } = null!;

    public string RequestorEmail { get; set; } = null!;

    public string RequestorDesc { get; set; } = null!;

    public string State { get; set; } = null!;

    public string City { get; set; } = null!;

    public int Pincode { get; set; }

    public int Id { get; set; }
}
