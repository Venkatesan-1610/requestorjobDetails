﻿namespace requestorJobDetailsAPI.Models
{
    public class insertReqDetails
    {
        public string RequestorName { get; set; } = null!;

        public string RequestorEmail { get; set; } = null!;

        public string RequestorDesc { get; set; } = null!;

        public string State { get; set; } = null!;

        public string City { get; set; } = null!;

        public int Pincode { get; set; }

        public byte[]? FileData { get; set; } 
        public string? FileMimeType { get; set; }

    }
}
