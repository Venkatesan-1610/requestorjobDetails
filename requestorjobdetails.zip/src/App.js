import "bootstrap/dist/css/bootstrap.min.css";
import "primeflex/primeflex.css";
import "primereact/resources/themes/saga-blue/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import Layout from "./components/Layout";
import {
  BrowserRouter as Router,
  Routes,Route
} from "react-router-dom";
import About from "./components/About";
import Home from "./components/Home";
import AddEmployee from "./components/AddEmployee";

function App() {
  return (
    <div>
      <Router>
      <div>
          <Layout>
            <Routes>
              <Route path="/about" element={<About />} />
              <Route path="/home" element={<Home />} />
              <Route path="/addEmployee" element={<AddEmployee />} />
            </Routes>
          </Layout>
        </div>
      </Router>
    </div>
  );
}

export default App;
