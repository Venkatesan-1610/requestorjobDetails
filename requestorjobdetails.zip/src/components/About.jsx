import React from "react";
import '../styles/About.scss'

function About() {
  return (
    <div className="about-container m-5 p-5">
      <h1>About Our Job Portal Application</h1>
      <p>
        Welcome to our Job Portal Application! Our platform is dedicated to making the job search and recruitment process seamless and efficient for both job seekers and employers. With an intuitive interface and a suite of powerful features, our application is designed to cater to all your job-related needs.
      </p>
      <h2>Features</h2>
      <ul>
        <li>Post and manage job listings easily.</li>
        <li>Search and apply for job openings using advanced filters and criteria.</li>
        <li>Track and manage job applications with an organized dashboard.</li>
        <li>Upload and manage employee resumes in PDF format.</li>
        <li>View detailed job descriptions and requirements directly on the platform.</li>
        <li>Receive notifications for new job listings and application updates.</li>
        <li>Secure data handling and storage to protect your personal information.</li>
      </ul>
      <h2>About Our Team</h2>
      <p>
        Our dedicated team is passionate about providing the best possible user experience. We continually work on enhancing our app and adding new features based on user feedback. Our goal is to make job searching and hiring as easy and effective as possible.
      </p>
      <p>
        We believe in the power of technology to transform the recruitment process, and we're here to support you every step of the way. If you have any suggestions or feedback, please feel free to reach out to us.
      </p>
      <p>
        Contact us at:{" "}
        <a href="mailto:support@jobportalapp.com">support@jobportalapp.com</a>
      </p>
    </div>
  );
}

export default About;
