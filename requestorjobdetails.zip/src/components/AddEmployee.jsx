import React, { useRef } from "react";
import { useForm } from "react-hook-form";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import "../styles/AddEmployee.scss";
import axios from "axios";
import Autocomplete from "react-google-autocomplete";
import { Toast } from "primereact/toast";
import { useNavigate } from "react-router";

const AddEmployee = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    trigger,
    reset,
  } = useForm({
  });
  const toast = useRef(null);
  const navigate = useNavigate();
  const showToast = (severity, detail) => {
    toast.current.show({
      severity,
      detail,
    });
  };

  const submitHandler = async (data) => {
    const formData = new FormData();
    formData.append("RequestorName", data.name);
    formData.append("RequestorEmail", data.email);
    formData.append("RequestorDesc", data.description);
    formData.append("State", data.address.state);
    formData.append("City", data.address.city);
    formData.append("Pincode", data.pincode);
    formData.append("file", data.file[0]);

    try {
        const response = await axios.post(
            "https://localhost:7062/api/requestorDetails/InsertRequestorDetails",
            formData,
            {
                headers: {
                    "Content-Type": "multipart/form-data",
                },
            }
        );

        showToast("success", `Employee added successfully.`);
        setTimeout(() => {
            navigate("/home");
        }, 3000);
        reset();
    } catch (error) {
        showToast("error", error.response.data.message || "Failed to add employee.");
    }
};


  const extractAddressComponent = (components, type) => {
    const component = components.find((c) => c.types.includes(type));
    return component ? component.long_name : "";
  };

  return (
    <div className="form-container">
      <Toast ref={toast} />
      <form onSubmit={handleSubmit(submitHandler)} className="p-fluid">
        <div className="row my-3">
          <div className="col-lg-4">
            <div className="p-field">
              <label htmlFor="name">Name</label>
              <InputText
                id="name"
                type="text"
                {...register("name", {
                  required: "Name is required",
                  pattern: {
                    value: /^[A-Za-z\s]+$/i,
                    message: "Name should contain alphabets only",
                  },
                })}
              />
              {errors.name && (
                <small className="error">{errors.name.message}</small>
              )}
            </div>
          </div>
          <div className="col-lg-4">
            <div className="p-field">
              <label htmlFor="email">Email</label>
              <InputText
                id="email"
                type="email"
                {...register("email", {
                  required: "Email is required",
                  pattern: {
                    value:
                      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
                    message: "Please enter a valid email id",
                  },
                })}
              />
              {errors.email && (
                <small className="error">{errors.email.message}</small>
              )}
            </div>
          </div>
          <div className="col-lg-4">
            <div className="p-field">
              <label htmlFor="description">Description</label>
              <InputText
                id="description"
                type="text"
                {...register("description", {
                  required: "description is required",
                })}
              />
              {errors.description && (
                <small className="error">{errors.description.message}</small>
              )}
            </div>
          </div>
          <div className="col-lg-4">
            <div className="p-field">
              <label htmlFor="address">Address</label>
              <Autocomplete
                id="address"
                {...register("address", {
                  validate: (value) => {
                    if (!value?.address) {
                      return "Address is required";
                    }
                    return true;
                  },
                })}
                className="p-inputtext p-component"
                apiKey="AIzaSyDQGedPbebrDKbLmKB6p3RB8z_ww7-J6bs"
                onPlaceSelected={(place) => {
                  const components = place.address_components;
                  const city = extractAddressComponent(components, "locality");
                  const state = extractAddressComponent(
                    components,
                    "administrative_area_level_1"
                  );
                  const address = place.formatted_address;
                  const location = {
                    address,
                    state,
                    city,
                  };
                  setValue("address", location);
                  trigger("address");
                }}
                placeholder=""
              />
              {errors.address && errors.address.message && (
                <small className="error">{errors.address.message}</small>
              )}
            </div>
          </div>
          <div className="col-lg-4">
            <div className="p-field">
              <label htmlFor="pincode">Pincode</label>
              <InputText
                id="pincode"
                type="text"
                {...register("pincode", {
                  required: "Postal code is required",
                  pattern: {
                    value: /^\d{5,6}$/,
                    message: "Please enter a valid postal code",
                  },
                })}
              />
              {errors.pincode && (
                <small className="error">{errors.pincode.message}</small>
              )}
            </div>
          </div>
          <div className="col-lg-4">
            <div className="p-field">
              <label htmlFor="file">Upload PDF File</label>
              <input
                id="file"
                type="file"
                {...register("file", {
                  required: "PDF file is required",
                  validate: {
                    acceptPDF: (value) =>
                      value[0]?.type === "application/pdf" ||
                      "Only PDF files are accepted",
                  },
                })}
                className="p-inputtext p-component"
              />
              {errors.file && (
                <small className="error">{errors.file.message}</small>
              )}
            </div>
          </div>
        </div>
        <div className="d-flex justify-content-end">
          <Button
            type="clear"
            className="secondary-button ml-3"
            label="Clear"
            onClick={() => {
              reset();
            }}
          />
          <Button
            type="submit"
            className="primary-button ml-3"
            label={"Submit"}
          />
        </div>
      </form>
    </div>
  );
};

export default AddEmployee;
