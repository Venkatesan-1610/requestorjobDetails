import React, { useEffect, useState } from "react";
import axios from "axios";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import "../styles/home.scss";
import Loader from "./Loader";

const Home = () => {

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://localhost:7062/api/requestorDetails/GetRequestorDetails');
        setLoading(false);
        setData(response.data);
        console.log(response);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };    
    fetchData();
  }, []);

  const fields = [
    { field: "requestorName", header: "Name", width: "15%" },
    { field: "requestorEmail", header: "Email", width: "15%" },
    { field: "requestorDesc", header: "Description", width: "40%" },
    { field: "city", header: "City", width: "" },
    { field: "state", header: "State", width: "" },
    { field: "pincode", header: "Pincode", width: "" },
  ];



  return (
    <div className="home-container m-5 p-5">
      {loading && <Loader />}
      <div className="card contact_datatable">
          <DataTable
            value={data}
            sortOrder={-1}
            tableStyle={{ minWidth: "50rem" }}
            paginator
            rows={10}
            dataKey="id"
          >
            {fields?.map((col) => (
              <Column
                key={col.field}
                field={col.field}
                header={col.header}
                sortable
                style={{ width: col.width }}
              />
            ))}
          </DataTable>
      </div>
    </div>
  );
};

export default Home;
