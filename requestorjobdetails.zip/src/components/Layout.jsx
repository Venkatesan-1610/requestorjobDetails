import Footer from "./Footer";
import NavBar from "./NavBar.jsx";
import '../styles/Layout.scss'

const Layout = ({ children }) => {
  return (
    <div>
      <NavBar />
      <div className="content">{children}</div>
      <Footer />
    </div>
  );
};

export default Layout;
