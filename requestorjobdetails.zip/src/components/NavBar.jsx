import { Link } from "react-router-dom";



const NavBar = () => {
  return (
    <div>
      <div className="navbar_wrapper">
        <div className="container">
          <div className="navbar_container">
            <div className="d-flex align-items-center">
            
              <div className="d-flex align-items-center title">
              <h5>Job Portal</h5>
              </div>
            </div>
            <div className="d-flex align-items-center">
              <ul>
                <li>
                  <Link to="/home">Home</Link>
                </li>
                <li>
                <Link to="/about">About</Link>
                </li>
                <li>
                <Link to="/addEmployee">AddEmployee</Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NavBar;
