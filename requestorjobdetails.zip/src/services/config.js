const config = {
    devApi: {
        spcHostUrl: "https://localhost:7271/api/"
    },

    api: {
        EmployeeDetails: "EmployeeDetails/GetEmployeeDetails",


    }
}
export default config;