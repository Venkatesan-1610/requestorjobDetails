import axios from "axios";
import { handleError, handleErrorWithStatus, handleResponse, handleResponseWithStatus } from "./response";
import config from './config';

const getBaseUrl = (resource) => {
    if(resource.includes('http') || resource.includes('https')) {
        return resource
    } else {
        return config.devApi.spcHostUrl + resource;
    }
}

const getBaseUrlById = (resource, id) => {
    if(resource.includes('http') || resource.includes('https')) {
        return resource
    } else {
        return config.devApi.spcHostUrl + resource + id;
    }
}

const getAll = (resource, cancelToken) => {
    return axios
        .get(getBaseUrl(resource), {
            cancelToken: cancelToken
        })
        .then(handleResponse)
        .catch(handleError)
}

const getDataById = (resource, id) => {
    return axios
        .get(getBaseUrlById(resource, id))
        .then(handleResponseWithStatus)
        .catch(handleErrorWithStatus)
}

const postCall = (resource, payload) => {
    return axios
        .post(getBaseUrl(resource), payload)
        .then(handleResponse)
        .catch(handleError)
}

const postCallById = (resource, id, payload) => {
    return axios
        .post(getBaseUrlById(resource, id), payload)
        .then(handleResponse)
        .catch(handleError)
}

const updateCall = (resource, payload) => {
     return axios
        .put(getBaseUrl(resource), payload)
        .then(handleResponse)
        .catch(handleError)
}

const updateCallById = (resource, id, payload) => {
    return axios
        .put(getBaseUrlById(resource,id), payload)
        .then(handleResponse)
}

const removeCall = (resource, payload) => {
    return axios
        .delete(getBaseUrl(resource), payload)
        .then(handleResponse)
        .catch(handleError)
}

export const apiProvider = {
    getAll,
    getDataById,
    postCall,
    postCallById,
    updateCall,
    updateCallById,
    removeCall
}